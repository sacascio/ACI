#!/usr/bin/env python


x = {}
y = {}

x['sal'] = ({ 'one': 1, 'two' : 2 })

print x['sal']

y['sally'] = x['sal']

print y['sally']
